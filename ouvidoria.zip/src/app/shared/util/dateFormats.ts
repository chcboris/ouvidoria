export const DateFormats = {
  parse: {
      dateInput: ['DD/MM/YYYY']
  },
  display: {
      dateInput: 'DD/MM/YYYY',
      monthYearLabel: 'MMMM YYYY',
      dateA11yLabel: 'L',
      monthYearA11yLabel: 'MMMM YYYY',
  },
};
