//import { environment } from "src/environments/environment";

export class Constantes {

    //Versão para testar direto no tomcat local - Substituir endpoint
    //static endpoint = 'http://localhost:4200/api-convocae-springboot';
    //static imagePath = '/convoca-e-form-angular/assets/img/';

    //static endpoint = environment.endPoint;

    //static imagePath = environment.imagePath;

    static versaoAtual = '1.0.0';

    //static ambiente = environment.ambiente;
    static ambiente = 'DESENV';

    //Senha de aplicacoo cryptografada
    //static appUser = 'Erwkdbn4pv1MZeODp9ZRRHK/7eUHcUTR';
    //static appPass = '4i67z74ZJSifU/yG6WAfhjXRhnBC9hus3C++/JHy9p8=';
}

