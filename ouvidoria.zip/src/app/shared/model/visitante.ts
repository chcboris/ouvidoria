export interface Visitante {
nome?: string;
documento?: string;
numeroDoc?: string;
telefone?: string;
empresa?: string;
destino?: string;
contato?: string;
ramal?: string
}