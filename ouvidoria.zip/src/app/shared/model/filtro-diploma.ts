export interface FiltroDiploma {
  anoReferencia?: number;
  dataNascimento?: Date;
  nomeCandidato?: string;
  nomeMae?: string;
  numeroCpf?: string;
}
